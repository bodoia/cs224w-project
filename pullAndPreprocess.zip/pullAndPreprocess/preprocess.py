import networkx as nx
import sys
import operator
import itertools
from collections import defaultdict

#topicsToInclude = ['currentAffairs', 'us', 'world', 'business', 'sports', 'nyregion', 'arts', 'fashion', 'science', 'technology', 'health', 'books']

def main():
   G = nx.read_edgelist("edges.txt")  

   sites = []
   with open("edges.txt") as f1:
      for line in f1.read().splitlines():
         (site, user) = line.split() 
         sites.append(site)

   groundTruth = {}
   with open("topics.txt") as f:
      for line in f.read().splitlines():
         (site, topic) = line.split()
         if site in list(G.nodes()):
            groundTruth[site] = topic

   for node in G.nodes():
      if (node in sites):
         if (node not in groundTruth):
            G.remove_node(node)
   
   Gnew = sorted(nx.connected_component_subgraphs(G), key = len, reverse=True)[1]


   with open('finalEdgeList.txt', 'a') as toWrite:
      for edge in Gnew.edges():
         if edge[0] in sites:
            strToWrite = str(edge[0]) + " " + str(edge[1]) + "\n"
         elif edge[1] in sites:
            strToWrite = str(edge[1]) + " " + str(edge[0]) + "\n"      
         toWrite.write(strToWrite)


if __name__ == '__main__':
	main()